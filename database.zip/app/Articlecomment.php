<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Articlecomment extends Model
{
      
    protected $fillable=['name','body'];
}
