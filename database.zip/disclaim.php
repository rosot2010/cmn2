<?php include("app_comp.php") ; ?><br /><br /><br /><br /><br />
<?php include("header_comp2.php") ; ?> 
     <div class="container-fluid">
  <div class="row">
                                       
                                   
						 <script src="adsbygoogle.js"></script>					
                                             <script src="modernizr.js"></script>
											 <script src="foundation.min.js"></script>
                                             <script>
                                             $(document).foundation();
                                             </script>
                                                               <link href="new_footer.css" rel="stylesheet"/>           	                	           	              
                                       <link rel="stylesheet" href="foundation.css" />
                               <link rel="stylesheet" type="text/css" href="media_suggest.css"/>
                               <link rel="stylesheet" type="text/css" href="myNstyle.css"/>
                         <link rel="stylesheet" type="text/css" href="rotate.css"/>
                      <link rel="stylesheet" type="text/css" href="normalize.css"/>
                     
                      <br /><br /><br /><br />
<div class="large-12 columns">
 <div class="panel">
<p style="color:black"; background:white">
<span style="color:red;font-weight:bold;font-size:18px;">Disclaimer:</span>
<span style="color:maroon;font-weight:bold;font-size:18px;">This</span> is a property advertisement platform provided and maintained by<p> <a href="index.php"style="color:maroon;font-weight:bold;font-size:18px;">houselink.ie</a></p>.
 and does not constitute property particulars. Whilst we require advertisers to act with best practice and provide accurate information,
 we can only publish advertisements in good faith and have not verified any claims 
 or statements or inspected any of the properties, locations or opportunities promoted. 
<p> <a href="index.php"style="color:maroon;font-weight:bold;font-size:18px;">houselink.ie</a></p> does not own or control and is not responsible for the properties, opportunities, 
 website content, products or services provided or promoted by third parties and makes no 
 warranties or representations as to the accuracy, completeness, legality, performance or suitability of any of 
 the foregoing. We therefore accept no liability arising from any reliance made by any user or person to whom this information is made available to.
 You must perform your own research and seek independent professional advice before making any decision to purchase or invest in  property/properties
 </p>

 </div>
     <script src="jquery.js"></script>
    <script src="modernizr.js"></script>
  <link rel="stylesheet" href="foundation.css" />
       <link rel="stylesheet" type="text/css" href="media_suggest.css">
     <link rel="stylesheet" type="text/css" href="normalize.css">
      <script src="foundation.min.js"></script>
             <script>
      $(document).foundation();
    </script>

 <?php include('footer.php') ;?>