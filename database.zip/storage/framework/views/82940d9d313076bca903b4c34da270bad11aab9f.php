<br /><br />

<?php $__env->startSection('content'); ?>
<header class="container-fluid">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
  
   
    <script src="./js/jquery.js"></script>
    <link href="./assets/sass/_variable.scss" rel="stylesheet"/> 
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="./css/app_naijatop100.css" rel="stylesheet"/>
    <link href="./css/app.css')}}" rel="stylesheet">

    <link href="./csslibs.css')}}" rel="stylesheet">
    <script src="./js/bootstrap.min.js"></script>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>  
      <a class="navbar-brand" href="#"style="color:white;"> 
       <img class="img-responsive" style="max-height:80px;" src="<?php echo e(URL::asset('images/aaarapower2.jpg')); ?>"/></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="<?php echo e(('http://localhost:8000/njproject/public')); ?>"style="color:red">Home <span class="sr-only">(current)</span></a></li>
          <li><a href="<?php echo e(('gallery')); ?>">Gallery</a></li>
          <li><a href="<?php echo e(('vote')); ?>">Vote</a></li>
          <li><a href="<?php echo e(('about')); ?>">About us</a></li>
          <li><a href="<?php echo e(('contact')); ?>">Contact us</a></li>
          <li><a href="<?php echo e(('news')); ?>">News</a></li>

          

        <li class="dropdown">
        <a href="<?php echo e(('event')); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Events<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(('#')); ?>">General Award nights</a></li>
            <li><a herf="<?php echo e(('#')); ?>">Gala Award nights</a></li>
            <li><a href="<?php echo e(('#')); ?>">Glo Award nights</a></li>
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
      
        <li class="dropdown">
          <a href="<?php echo e(('login')); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Login <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(('register')); ?>">Sign up</a></li>
            <li><a href="<?php echo e(('login')); ?>">Sign up</a></li>

          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
 
</nav>

<div class="container-fluid">
  <div class="row">
     <aside class="col-sm-2">
     <ul class="nav" id="side-menu">
     
           <li>
               <a href="/admin"><i class="fa fa-dashboard fa-fw"></i> Main event</a>
           </li>

           <li>
               <a href="#"><i class="fa fa-wrench fa-fw"></i>Vote<span class="fa arrow"></span></a>
               <ul class="nav nav-second-level">
                   <li>
                       <a href="/users">Vote Results</a>
                   </li>

                   

               </ul>
               <!-- /.nav-second-level -->
           </li>  <li>
                        <a href="#"><i class="fa fa-sitemap fa-fw"></i>Interviews<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Recent Interviews</a>
                            </li>
                            <li>
                                <a href="#">Old Interviews</a>
                            </li>
                            <li>
                                <a href="#">Events <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Event Venues</a>
                                    </li>
                                    <li>
                                        <a href="#">Upcoming event</a>
                                    </li>
                                    <li>
                                        <a href="#">Past event</a>
                                    </li>
                                    <li>
                                        <a href="#">Gist and comments</a>
                                    </li>
                                </ul>
                                <!-- /.nav-third-level -->
                            </li>
                        </ul>
                        <!-- /.nav-second-level -->
                    </li></ul>                                                                                         
     </aside>
     
     <section class="col-sm-4">
     <article>
<h2>Upload News</h2>

<?php echo Form::open(['method'=>'POST','action'=>'ArticlesController@store','files'=>true]); ?>

<div class="form-group">
<?php echo Form::label('Title','Title'); ?>

<?php echo Form::text('title',null,['class'=>'form-control']); ?><br />
<?php echo Form::label('title','content','image_path'); ?>

<?php echo Form::textarea('content',null,['class'=>'form-control']); ?>



                 </div><br />
                 <div class="form-group"> 

<?php echo Form::file('file',['class'=>'form-control']); ?>



                 </div>                         
<?php echo Form::submit('submit',['class'=>'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
<ul> 
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
</article>
</section>
</article></div></div>
    <div style="margin-top:50px;"></div>
<footer class="container-fluid">
   
        <div class="container-fluid">
                <div class="row">
                        <section class="col-sm-4">
                      

                          <ul class="footer-links">
                                <li><a href="advert1_forsale.php">Advertise for sale</a></li>
                                      <li><a href="advert1_forsale.php">Advertise to let</a></li>
                                          <li><a href="advert1_forsale.php">Advertise holiday home</a></li>
                                      <li><a href="advert1_forsale.php">Advertise comm ppt</a></li>
                                   <li><a href="advert1_forsale.php">Advertise overseas ppt</a></li>
                               <li><a href="letting.php">Letting</a></li>	
                          </ul>
                        </section>
                        <section class="col-sm-4">

                           <ul class="footer-links">
                                <li><a href="forsale1.php">For sale</a></li>
                                         <li><a href="letting.php">Letting</a></li>
                                               <li><a href="sharing.php">Sharing</a></li>
                                         <li><a href="commercial.php">Commercial ppties</a></li>

                                         <li><a href="site_map.php">Site map</a></li>
                               
                           </ul>
                        </section>
                        <section class="col-sm-4">
                         <ul class="footer-links">
                                 <li><a href="holiday_home.php">Holiday home</a></li>
                                      <li><a href="">Overseas properties</a></li>
                                                 
                                      <li><a href="#"><img src =""></a></li>
                                      
                                       <li></li>
                                  <li></li>
                             
                           
                         </ul>
                        </section>
                </div></div>
</footer> 
    
<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>