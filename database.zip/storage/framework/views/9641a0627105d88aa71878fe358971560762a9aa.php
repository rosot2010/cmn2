<br /><br />

<?php $__env->startSection('content'); ?>
<header class="container-fluid">
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
   <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"/>
  
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
    <script src="../js/jquery.js"></script>
    <link href="./assets/sass/_variable.scss" rel="stylesheet"/> 
    <link href="./css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app_naijatop100.css" rel="stylesheet"/>
    <link href="./css/app.css')}}" rel="stylesheet">

    <link href="./css/libs.css')}}" rel="stylesheet">
    <script src="../js/bootstrap.min.js"></script>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>  
      <a class="navbar-brand" href="#"style="color:white;"> 
       <img class="img-responsive" style="max-height:80px;" src="<?php echo e(URL::asset('images/aaarapower2.jpg')); ?>"/></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
      <li><a href="<?php echo e(('/home')); ?>">Home <span class="sr-only">(current)</span></a></li>
      <li><a href="<?php echo e(('/gallery')); ?>">Gallery</a></li>
      <li><a href="<?php echo e(('/post')); ?>">Forum</a></li>
      <li><a href="<?php echo e(('/about')); ?>">About us</a></li>
      <li><a href="<?php echo e(('/contact')); ?>">Contact us</a></li>
      <li><a href="<?php echo e(('/articles')); ?>">News</a></li>

          

        <li class="dropdown">
        <a href="<?php echo e(('event')); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Events<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(('#')); ?>">General Award nights</a></li>
            <li><a herf="<?php echo e(('#')); ?>">Gala Award nights</a></li>
            <li><a href="<?php echo e(('#')); ?>">Glo Award nights</a></li>
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
      <!-- Authentication Links -->
      <?php if(auth()->guard()->guest()): ?>
          <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
          <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
      <?php else: ?>
          <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
                  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
              </a>

              <ul class="dropdown-menu">
                  <li>
                      <a href="<?php echo e(route('logout')); ?>"
                          onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                          Logout
                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                      </form>
                  </li>
              </ul>
          </li>
      <?php endif; ?>
  </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
 
</nav>
<br />
<div class="container-fluid">
  <div class="row">
  <aside class="col-sm-2">
  <ul class="nav" id="side-menu">
  
        <li>
            <a href="<?php echo e(('/photos/create')); ?>"><i class="fa fa-dashboard fa-fw"></i> Upload Event Pics</a>
        </li>

        <li>
            <a href="<?php echo e(('/post')); ?>"><i class="fa fa-wrench fa-fw"></i>Vote<span class="fa arrow"></span></a>
            <ul class="nav nav-second-level">
                <li>
                    <a href="<?php echo e(('result')); ?>">Vote Results</a>
                </li>

                

            </ul>
            <!-- /.nav-second-level -->
        </li>  <li>
                     <a href="#"><i class="fa fa-sitemap fa-fw"></i>Interviews<span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
                         <li>
                             <a href="#">Recent Interviews</a>
                         </li>
                         <li>
                             <a href="#">Old Interviews</a>
                         </li>
                         <li>
                             <a href="#">Events <span class="fa arrow"></span></a>
                             <ul class="nav nav-third-level">
                                 <li>
                                     <a href="#">Event Venues</a>
                                 </li>
                                 <li>
                                     <a href="<?php echo e(('/photos/create')); ?>">Upload Recent</a>
                                 </li>
                                 <li>
                                     <a href="<?php echo e(('/photos')); ?>">Recent eventuploads </a>
                                 </li>
                                 <li>
                                     <a href="#">Gist and comments</a>
                                 </li>
                                 <li>
                                 <a href="<?php echo e(('/posts/create')); ?>">Admin</a>
                                 <a href="<?php echo e(('/articles/create')); ?>">Admin2</a>
                                 </li>
                             </ul>
                             <!-- /.nav-third-level -->
                         </li>
                     </ul>
                     <!-- /.nav-second-level -->
                 </li></ul>                                                                                         
  </aside>
     <aside class="col-sm-2">
                                                                                                                                                                                                                  </a>
     </aside>
  <section class="col-sm-4">
<article>
<h2>Post Artist</h2>

<?php echo Form::open(['method'=>'store','action'=>'PostsController@store','files'=>true]); ?>

<div class="form-group">
<?php echo Form::label('artist_name','Artist name'); ?>

<?php echo Form::text('artist_name',null,['class'=>'form-control']); ?><br />
<?php echo Form::label('artist name','record label','image_path'); ?>

<?php echo Form::text('record_label',null,['class'=>'form-control']); ?>



                 </div><br />
                 <div class="form-group"> 
                
 <?php echo Form::label('photo','Photo'); ?><br />         
<?php echo Form::file('file',['class'=>'form-control']); ?>

<?php echo Form::label('photo','Video'); ?><br />         
<?php echo Form::file('file',['class'=>'form-control']); ?>

                 </div>                         
<?php echo Form::submit('Post',['class'=>'btn btn-primary']); ?>

</div>

<?php echo Form::close(); ?>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
<ul> 
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
</article>
       

  </section>
 
</div>
</div>  
<footer class="container-fluid">

     <div class="container-fluid">
             <div class="row">
                     <section class="col-sm-4">
                   

                       <ul class="footer-links">
                             <li><a href="<?php echo e(('/home')); ?>">Home</a></li>
                                   <li><a href="<?php echo e(('/Gallery')); ?>">Gallery</a></li>
                                       <li><a href="<?php echo e(('/post')); ?>">Vote</a></li>
                                   <li><a href="<?php echo e(('/articles')); ?>">News</a></li>
                                <li><a href="<?php echo e(('/events')); ?>">Events</a></li>
                            <li><a href="<?php echo e(('/contact')); ?>">Contact Us</a></li>	
                       </ul>
                     </section>
                     <section class="col-sm-4">

                        <ul class="footer-links">
                             <li><a href="<?php echo e(('about')); ?>">About Us</a></li>
                                      <li><a href="<?php echo e(('/Advert')); ?>">Advertise with us</a></li>
                                            <li><a href="<?php echo e(('login')); ?>">Login</a></li>
                                      <li><a href="<?php echo e(('register')); ?>">Sign Up</a></li>

                                      <li><a href="<?php echo e(('map')); ?>">Site map</a></li>
                            
                        </ul>
                     </section>
                     <section class="col-sm-4">
                      <ul class="footer-links">
                              <li><a href="<?php echo e(('/post')); ?>">like</a></li>
                                   <li><a href="<?php echo e(('/contact')); ?>">Office</a></li>
                                              
                                   <p style="font-size:13px;font-style:italic;text-align:center;color:white">All information on this site is <strong>&copy;naijatop100hitz<a  href="#"style="color:orange">Privacy policy.</a><a href="<?php echo e(('/disclaim')); ?>"style="color:orange;"> Disclaimer.</a></p>
                                   
                                   
                          
                        
                      </ul>
                     </section>
             </div></div>
</footer> 
  
    
<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>