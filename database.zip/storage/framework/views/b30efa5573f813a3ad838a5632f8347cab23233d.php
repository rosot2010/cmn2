<ul style="list-style-type:none;margin-top:-50px;">
  
<li><img style="max-height:500px;width:500px;" src="../images/<?php echo e($post->image_path); ?>"alt="image"></a></li> 
<li>


<button class="btn-success btn"click()>vote</button>
</ul>  <h3>Comment</h3>
    <section class="col-sm-4">
<?php echo Form::open(['method'=>'store','action'=>'commentsController@store']); ?>

<div class="form-group">
<?php echo Form::label('name','Name'); ?>

<?php echo Form::text('name',null,['class'=>'form-control']); ?><br />
<?php echo Form::label('comment','Comment'); ?>

<?php echo Form::textarea('body',null,['class'=>'form-control']); ?>

<?php echo Form::submit('post',['class'=>'btn btn-primary']); ?>

</div>
<?php echo Form::close(); ?>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
<ul> 
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($error); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
</section></article>