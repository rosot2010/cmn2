<?php echo Form::open(['method'=>'store','action'=>'PostsController@store','files'=>true]); ?>

<div class="form-group">
<?php echo Form::label('artist_name','Artist name'); ?>

<?php echo Form::text('artist_name',null,['class'=>'form-control']); ?><br />