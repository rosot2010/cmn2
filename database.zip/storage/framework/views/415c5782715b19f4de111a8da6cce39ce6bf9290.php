<article>
     <h3>|hh|</h3>
     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <ul style="list-style-type:none">
     <li>{<?php echo $post->artist_name; ?>}</li>
     <li>{<?php echo $post->record_label; ?>}</li>
     
     </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h2>Edit post</h2>

<?php echo Form::model($post,['method'=>'PATCH','action'=>['PostsController@update',$post->id]]); ?>

<?php echo e(csrf_field()); ?> 
<?php echo Form::text('artist_name',null,['class'=>'form-control']); ?>

<?php echo e(csrf_field()); ?> 
<?php echo Form::text('record_label',null,['class'=>'form-control']); ?>


                 <?php echo e(csrf_field()); ?> 
                 <?php echo Form::submit('Update post',['class'=>'btn btn-info']); ?>

                 <?php echo Form::close(); ?>


                 <h2>Delete post</h2>
<?php echo Form::model($post,['method'=>'DELETE','action'=>['PostsController@destroy',$post->id]]); ?>

<?php echo e(csrf_field()); ?> 
<?php echo Form::text('artist_name','record_label',null,['class'=>'form-control']); ?>

                    <?php echo e(csrf_field()); ?> 

                    <?php echo Form::submit('Delete post',['class'=>'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>


                    