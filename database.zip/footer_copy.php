<footer class="container-fluid">
   
        <div class="container-fluid">
                <div class="row">
                        <section class="col-sm-4">
                      

                          <ul class="footer-links">
                                <li><a href="advert1_forsale.php">Advertise for sale</a></li>
                                      <li><a href="advert1_forsale.php">Advertise to let</a></li>
                                          <li><a href="advert1_forsale.php">Advertise holiday home</a></li>
                                      <li><a href="advert1_forsale.php">Advertise comm ppt</a></li>
                                   <li><a href="advert1_forsale.php">Advertise overseas ppt</a></li>
                               <li><a href="letting.php">Letting</a></li>	
                          </ul>
                        </section>
                        <section class="col-sm-4">

                           <ul class="footer-links">
                                <li><a href="forsale1.php">For sale</a></li>
                                         <li><a href="letting.php">Letting</a></li>
                                               <li><a href="sharing.php">Sharing</a></li>
                                         <li><a href="commercial.php">Commercial ppties</a></li>

                                         <li><a href="site_map.php">Site map</a></li>
                               
                           </ul>
                        </section>
                        <section class="col-sm-4">
                         <ul class="footer-links">
                                 <li><a href="holiday_home.php">Holiday home</a></li>
                                      <li><a href="">Overseas properties</a></li>
                                
                                    
                                       <li></li><br />
                                  <li> <span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=Tihczp6kWrLjKpqH7fcWuXsEjSNtqCAdj4w38d148q5IRmRtw8SwbXEOVTeR"></script></span></li>
                            
                           
                         </ul>
                        </section><li style="list-style-type:none;"><a href="mailto:joan444@houselink.ie">click here to send a  message to houselink.ie
</a></li>
                </div><span><a href="mailto:sotonahenry@houselink.ie">Engineered by Rosot:sotonahenry@houselink.ie</span></div>
                 </div><span>+353899440508</span></div>
                 <p style="font-size:13px;font-style:italic;text-align:center;color:white">All information on this site is <strong>&copy;houselink.ie<a  href="privacy_policy.php"style="color:orange">Privacy policy.</a><a href="disclaim.php"style="color:orange;"> Disclaimer.</a></p>
</footer>