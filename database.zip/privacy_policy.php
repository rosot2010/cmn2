<?php include("app_comp.php") ; ?><br /><br /><br /><br /><br />
<?php include("header_comp2.php") ; ?> 
     <div class="container-fluid">
  <div class="row">
                                       
                                   
						 <script src="adsbygoogle.js"></script>					
                                             <script src="modernizr.js"></script>
											 <script src="foundation.min.js"></script>
                                             <script>
                                             $(document).foundation();
                                             </script>
                                                               <link href="new_footer.css" rel="stylesheet"/>           	                	           	              
                                       <link rel="stylesheet" href="foundation.css" />
                               <link rel="stylesheet" type="text/css" href="media_suggest.css"/>
                               <link rel="stylesheet" type="text/css" href="myNstyle.css"/>
                         <link rel="stylesheet" type="text/css" href="rotate.css"/>
                      <link rel="stylesheet" type="text/css" href="normalize.css"/>
                     
                      <br /><br /><br /><br />
<div class="large-12 columns">
 <div class="panel">
<p style="color:black" background:white">
<span style="color:red;font-weight:bold;font-size:18px;">Privacy Policy</span>
<p style="color:black" background:white">
Below is the main Privacy Statement for <a href="index.php"style="color:maroon">houselink.ie.</a><strong>Please read </strong>
 these while registering for our services.
Here at <a href="index.php"style="color:maoon">houselink.ie</a>, we ask for users email solely for the folowing reasons.
1.contact in case of a lost passoword.
2.To help us monitor and improve the services we offer to you.

<p><strong><a href="index.php"style="colormaroon;">houselink.ie</a></strong> do not share your email address with anyone.
Use of Cookies:We use cookies as it is a statndard requirement set by internet governing body for all applications like ours.<br />
<a href="index.php"style="color:maroon">houselink .ie</a> Advertising:for all matters relating to advertising, contact joan444@houselink.ie.</p> 
<p style="color:black" background:white">
<a href="index.php"style="color:maoon;font-weight:bold;font-sizex;">houselink.ie</a> does our utmost to protect your privacy through the appropriate use of security technology. This means:
We ensure that we have appropriate physical and technological security measures in place to protect your information.
We ensure that when we use other service providers for any processes, these service providers also have appropriate security measures
 in place to protect your information.
<a href="index.php">houselink.ie</a> respects your privacy. when you receive marketing emails from us,  It will be made clear to you why, and an unsuscribe link will be right in place to enable you opt-out incase you are not interested in receiving our marketing emails anymore
<a href="index.php"style="color:mroon">Houselink.ie</a> may, however, email you occasionally with information or questions about your account in case we see 
areas where we can assist you in using our appllication/site.
<a href="index.php">Houselink.ie</a> will only collect and use your information where we have legitimate business reasons, and we are legally entitled to do so.
Houselink.ie will only use your information for the purpose(s) for which they were originally collected and we will ensure any old information is securely 
disposed of.
The minimum information we need to register a consumer is an <strong>email address and a password.</strong> 
</p>
<p style="color:black" background:white">
If you access our Online Services from a mobile or other device, we may collect a unique device identifier assigned to that device ("UDID").
This information is used to personalize your experience across all < href="index.php">houselink.ie</a> platform. It also allows us to display relevant content, services and advertising to the appropriate audience.
<strong>Use of Cookies</strong>
<a href="index.php">houselink.ie</a> use cookies for this reasons.
whether a visitor has seen an advertisement and if so, how long ago, how many have seen the advertisement once and
how many have seen it more than once. 
Placing cookies on your computer means houselink.ie may serve you advertisements possibly more interesting to you, and allows us to 
control the number of times you see advertisements and measure effectiveness of ad campaigns .
You can turn cookies off, but if you do this, you may not be able to use some services on the houselink.ie site, and you might see more pop-ups and 
other intrusive advertising, as we won't be able to limit what you see using cookies. You will however still be able to view our site.

By permitting cookies to be used you are agreeing to the use of cookies as described above.

</p>
 </div>
 <?php include('footer.php') ;?>
